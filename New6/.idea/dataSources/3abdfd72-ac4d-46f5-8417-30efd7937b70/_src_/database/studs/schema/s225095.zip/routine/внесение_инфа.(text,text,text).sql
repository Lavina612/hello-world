create function "внесение_инфа"(name text, job text, place text) returns void
LANGUAGE plpgsql
AS $$
DECLARE 
chel int; 
rab int;
mesto int; 
BEGIN 
SELECT ИД INTO STRICT chel FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name or ИМЯ_ЧЕЛ=name; 
SELECT ИД INTO STRICT rab FROM ДОЛЖНОСТЬ WHERE НАЗВАНИЕ=job; 
SELECT ИД INTO STRICT mesto FROM МЕСТО WHERE МЕСТО=place; 
INSERT INTO ИНФА_ЧЕЛ VALUES(chel, rab, mesto); 
raise notice 'Inserted into ИНФА_ЧЕЛ %, %, %', chel, rab, mesto; 
EXCEPTION 
WHEN NO_DATA_FOUND THEN 
RAISE NOTICE 'You entered incorrect data'; 
RETURN; 
END;
$$;
