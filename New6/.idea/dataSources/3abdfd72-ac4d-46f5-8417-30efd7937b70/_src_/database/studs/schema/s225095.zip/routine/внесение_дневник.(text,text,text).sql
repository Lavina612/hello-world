create function "внесение_дневник"(name1 text, place text, name2 text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
chel1 int;
chel2 int;
place_where int;
BEGIN
SELECT ИД INTO STRICT chel1 FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name1;
SELECT ИД INTO STRICT chel2 FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name2;
SELECT ИД INTO STRICT place_where FROM МЕСТО WHERE МЕСТО=place;
INSERT INTO ДНЕВНИК VALUES(1, chel1, chel2, place_where);
raise notice 'Inserted into ДНЕВНИК %, %, %', chel1, chel2, place_where;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;
