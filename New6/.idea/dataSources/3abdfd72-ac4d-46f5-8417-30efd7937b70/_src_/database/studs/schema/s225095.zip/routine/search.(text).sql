create function search(phrase text) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE
  phrase2 text [];
  yi text;
  arLength integer;
  count integer;
  i integer;
BEGIN
  count=0;
  phrase=lower(phrase);
  phrase2 = regexp_split_to_array(phrase, '(\. |, | |,|\.)');
  arLength=array_length(phrase2, 1);
  create temp TABLE ONTIME1(
    id_ep integer,
    number integer,
    where_is integer
  );
  create temp TABLE ONTIME2(
    id_ep integer,
    number integer,
    where_is integer
  );
  create temp TABLE ONTIME3(
    id_ep integer,
    number integer,
    where_is integer
  );
  INSERT into ONTIME2
    (select PLACE_OF_WORD.id_ep, PLACE_OF_WORD.number, PLACE_OF_WORD.where_is from PLACE_OF_WORD
      inner join WORDS on (WORDS.ИД=PLACE_OF_WORD.id_word) where WORDS.word=phrase2[1]);
  INSERT into ONTIME1 (SELECT * from ONTIME2);
  FOR i in 2..arLength
  LOOP
    yi=phrase2[i];
    count=count+1;
    EXECUTE 'INSERT into ONTIME3
(select PLACE_OF_WORD.id_ep, PLACE_OF_WORD.number, PLACE_OF_WORD.where_is' ||
            ' from PLACE_OF_WORD inner join WORDS on (WORDS.ИД=PLACE_OF_WORD.id_word) where WORDS.word=''' || yi || ''');';
    delete from ONTIME1;
    UPDATE ONTIME3 set number=number-count;
    insert into ONTIME1 (SELECT * from ONTIME2 INTERSECT select * from ONTIME3);
  END LOOP;
  return QUERY select DISTINCT id_ep from ONTIME1 ORDER BY id_ep;
  drop table ONTIME1;
  drop table ONTIME2;
  drop table ONTIME3;
END;
$$;
