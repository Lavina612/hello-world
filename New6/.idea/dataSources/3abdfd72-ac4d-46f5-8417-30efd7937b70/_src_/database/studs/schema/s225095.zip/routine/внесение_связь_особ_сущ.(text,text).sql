create function "внесение_связь_особ_сущ"(name text, charact text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
such int;
osob int;
BEGIN
SELECT ИД INTO STRICT such FROM СУЩЕСТВО WHERE СУЩЕСТВО=name;
SELECT ИД INTO STRICT osob FROM ОСОБЕННОСТЬ WHERE ОПИСАНИЕ_ОСОБ=charact;
INSERT INTO СВЯЗЬ_ОСОБ_СУЩ VALUES(such, osob);
raise notice 'Inserted into СВЯЗЬ_ОСОБ_СУЩ %, %', such, osob;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;
