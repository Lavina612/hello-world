create function fail3() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
IF MOD(NEW.ИД,3)=0 THEN
NEW.ПРИЧИНА='FAIL';
END IF;
RETURN NEW;
END;
$$;
