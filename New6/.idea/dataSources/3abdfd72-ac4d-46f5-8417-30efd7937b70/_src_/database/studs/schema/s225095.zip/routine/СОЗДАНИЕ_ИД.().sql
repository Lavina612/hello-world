create function "СОЗДАНИЕ_ИД"() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
maximum int;
counter int;
BEGIN
EXECUTE 'SELECT COUNT(*) FROM ' || TG_TABLE_NAME || ' WHERE ИД=' || NEW.ИД  || ';' INTO counter;
IF counter=1 THEN
EXECUTE 'SELECT MAX(ИД) FROM ' || TG_TABLE_NAME || ';' INTO maximum;
NEW.ИД:=maximum+1;
END IF;
RETURN NEW;
END;
$$;
