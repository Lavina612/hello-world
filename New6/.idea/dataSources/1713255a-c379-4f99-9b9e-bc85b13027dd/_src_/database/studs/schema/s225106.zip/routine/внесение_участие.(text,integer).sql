create function "внесение_участие"(name text, nymber integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE
chel int;
epiz int;
BEGIN
SELECT ИД INTO STRICT chel FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name;
SELECT ИД INTO STRICT epiz FROM ЭПИЗОД WHERE ИД=number;
INSERT INTO УЧАСТИЕ VALUES(chel, epiz);
raise notice 'Inserted into УЧАСТИЕ %, %', chel, epiz;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;
