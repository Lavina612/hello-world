create function "удаление"() returns void
LANGUAGE plpgsql
AS $$
DECLARE 
  i integer;
BEGIN
 -- FOR i in REVERSE 100050..100050
   -- LOOP
  i =100050;
      EXECUTE 'DELETE from ЧЕЛОВЕК WHERE ИД=' || i || ';';
      raise NOTICE '%',i;
 -- END LOOP;
END;
$$;
