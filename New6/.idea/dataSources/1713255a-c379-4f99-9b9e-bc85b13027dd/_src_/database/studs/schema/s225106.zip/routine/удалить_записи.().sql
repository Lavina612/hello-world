create function "удалить_записи"() returns void
LANGUAGE plpgsql
AS $$
BEGIN
    delete from ЧЕЛОВЕК where ИД>50;
    delete from "СВЯЗЬ_ОСОБ_ЧЕЛ" where ИД_ЧЕЛ>50;
    delete from "СУЩЕСТВО" where ИД>31;
    delete from "СВЯЗЬ_ОСОБ_СУЩ" where ИД_СУЩ>31;
    delete from "ИНФА_ЧЕЛ" where ИД_ЧЕЛ>50;
    delete from "ЭПИЗОД" where ИД>25;
    delete from "УЧАСТИЕ" where ИД_ЧЕЛ>50;
    delete from "СВЯЗЬ_МЕСТА" where ИД_ЭПИЗ>25;
END;
$$;
