create function "внесение_связь_должн"(name text, dolg text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
chel int;
dolgn int;
BEGIN
SELECT ИД INTO STRICT chel FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name or ИМЯ_ЧЕЛ=name;
SELECT ИД INTO STRICT dolgn FROM ДОЛЖНОСТЬ WHERE НАЗВАНИЕ=dolg;
INSERT INTO СВЯЗЬ_ДОЛЖН VALUES(chel, dolgn);
raise notice 'Inserted into СВЯЗЬ_ДОЛЖН %, %', chel, dolgn;
EXCEPTION
	WHEN NO_DATA_FOUND THEN 
		RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;
