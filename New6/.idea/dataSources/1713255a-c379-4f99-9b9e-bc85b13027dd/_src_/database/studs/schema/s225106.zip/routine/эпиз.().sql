create function "эпиз"() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
IF MOD(NEW.ИД,3)=0 THEN
NEW.ПРИЧИНА='FAIL';
raise notice 'Hello';
END IF;
RETURN NEW;
END;
$$;
