create function "внесение_связь_раб"(dolg text, place text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
dolgn int;
place_work int;
BEGIN
SELECT ИД INTO STRICT dolgn FROM ЧЕЛОВЕК WHERE НАЗВАНИЕ=dolg;
SELECT ИД INTO STRICT place_work FROM МЕСТО WHERE МЕСТО=place;
INSERT INTO СВЯЗЬ_РАБ VALUES(dolgn, place_work);
raise notice 'Inserted into СВЯЗЬ_РАБ %, %', dolgn, place_work;
EXCEPTION
	WHEN NO_DATA_FOUND THEN 
		RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;
