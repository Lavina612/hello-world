create function "запрос"(index integer) returns SETOF record
LANGUAGE SQL
AS $$
SELECT ЧЕЛОВЕК.ИД, ИМЯ_ЧЕЛ, КОРОТКОЕ_ИМЯ, ПОЛ_ЧЕЛ, ВОЗРАСТ_ЧЕЛ, НАЗВАНИЕ, МЕСТО FROM ЧЕЛОВЕК, ДОЛЖНОСТЬ, ИНФА_ЧЕЛ, МЕСТО 
WHERE ИНФА_ЧЕЛ.ИД_ЧЕЛ=index AND ЧЕЛОВЕК.ИД = index AND ИНФА_ЧЕЛ.ИД_ДОЛЖН=ДОЛЖНОСТЬ.ИД AND ИНФА_ЧЕЛ.ИД_МЕСТА=МЕСТО.ИД;
$$;
